/* SPDX-License-Identifier: MIT -- independent desktop example, no device access */
#include "dm_vqf.h"
#include <stdio.h>

int main(void)
{
    DmVqf filter;
    if (!dm_vqf_init(&filter, NULL, 0.0005f)) return 1;

    /* 模拟静止 IMU 的 Z 轴偏置 0.05 deg/s。真实应用替换为已标定输入。 */
    const float gyro[3] = {0, 0, 0.05f*0.017453292519943295f};
    const float acc[3] = {0, 0, 9.80665f};
    puts("time_s,rest,bias_z_deg_s,roll_deg,pitch_deg,yaw_deg");
    for (int sample = 1; sample <= 120000; ++sample) {
        if (!dm_vqf_update(&filter, gyro, acc)) return 2;
        if (sample % 2000 == 0) {
            float euler[3];
            dm_vqf_get_euler_deg(&filter, euler);
            printf("%d,%d,%.9g,%.9g,%.9g,%.9g\n", sample/2000,
                filter.rest_detected, filter.bias_rad_s[2]*57.29577951308232f,
                euler[0], euler[1], euler[2]);
        }
    }
    return 0;
}
