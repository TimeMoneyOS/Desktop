# DM VQF 六轴解算库：项目接入与代码阅读

本目录已经整理为独立 C11 解算库。核心只需两个 `.c`、两个 `.h`，不依赖 HAL、RTOS、C++、操作系统或动态内存。使用时保留 LICENSE。算法与系数以此前审计版本为基准，包含已确认的原固件标定协方差倍率和欧拉角边界。

## 1. 文件用途与最小依赖

| 文件 | 是否加入工程 | 用途 |
|---|---|---|
| `dm_vqf.c` | 必须编译 | 参数初始化、静止判断、姿态更新、偏置估计、输出转换 |
| `dm_vqf.h` | 必须保留 | 唯一应用公开接口、参数和实例结构，含中文 Doxygen 注释 |
| `dm_vqf_math.c` | 必须编译 | 四元数、低通和三阶矩阵运算 |
| `dm_vqf_math.h` | 必须保留 | 内部跨文件声明，应用不要直接调用 |
| `CMakeLists.txt` | CMake 工程使用 | 静态库目标 `dm_vqf::dm_vqf`，可选桌面示例 |
| `examples/imu_fusion_port.c/.h` | 可选 | 无硬件依赖的应用适配参考；不是传感器驱动 |
| `example.c` | 桌面演示时编译 | 自带 main 的固定输入模拟，不加入 MCU 应用 |
| `LICENSE` | 保留 | VQF 的 MIT 授权与版权信息 |

`compare_reference.cpp`、`build_and_test.ps1` 和各审计脚本为验证工具，不加入嵌入式工程。内部非 static 辅助符号统一以 `dm_vqf_math_` 开头，避免与其它库的 `quat_multiply`、`mat3_inverse` 等重名。

标准库需求是 `stdbool.h/stddef.h/float.h/string.h/math.h`；数学库须提供 `sinf/cosf/sqrtf/acosf/asinf/atan2f/fmaf`、double `tan/sqrt` 及有限值/NaN 检查。保留 32 位 float、64 位 double，不可把 double 状态改为 float。

## 2. 手动加入 Keil、STM32CubeIDE 或其它工程

1. 复制上述四个核心文件到工程目录，例如 `Middlewares/dm_vqf/`。
2. 将两个 `.c` 加入工程编译，并将该目录加入头文件搜索路径；按 C11 或支持所用 C99 特性的 C 编译器编译，不把 `.c` 当 C++。
3. 按 MCU 选择正确的 CPU/FPU/float ABI，与项目其它目标文件一致；数学库链接遵循对应工具链配置。GCC 桌面/部分交叉环境需要 `-lm`。
4. 以已校准的陀螺 rad/s、加速度 m/s² 调用安全更新接口。
5. 每次有效采样仅调用一次更新；默认标定初始化固定 0.5 ms，采样来源应为 2 kHz 数据就绪事件或同等可靠调度。

库不指定芯片、时钟、中断和实时优先级，也不隐式对输入做滤波或标定。MCU 实时开销请在目标硬件测量：double 低通和 3×3 偏置估计可能使用软件 double 运算，桌面执行速度不能作为 MCU 用时依据。

## 3. CMake 接入

在上层工程已经 `project(... LANGUAGES C)` 后添加：

```cmake
add_subdirectory(Middlewares/dm_vqf)
target_link_libraries(your_app PRIVATE dm_vqf::dm_vqf)
```

应用中只需 `#include "dm_vqf.h"`。可选适配例子需自行添加：

```cmake
target_sources(your_app PRIVATE Middlewares/dm_vqf/examples/imu_fusion_port.c)
target_include_directories(your_app PRIVATE Middlewares/dm_vqf/examples)
```

独立桌面构建（以本目录为工作目录，已经配置好 C 编译器）：

```powershell
cmake -S . -B build/cmake -G Ninja -DDM_VQF_BUILD_EXAMPLE=ON
cmake --build build/cmake
./build/cmake/dm_vqf_example.exe
```

Linux/macOS 的示例可执行文件没有 `.exe` 后缀。交叉编译时在首次配置 CMake 就传入项目工具链文件，保持示例开关 OFF。静态库也支持 `cmake --install ... --prefix ...`，安装后可使用生成的 `lib/cmake/dm_vqf/dm_vqfTargets.cmake` 导入目标。

## 4. 最小运行流程

```c
#include "dm_vqf.h"

static DmVqf filter;  /* 状态较多，优先静态分配，避免放进小任务栈。 */
static bool filter_ready;

bool fusion_init(void)
{
    filter_ready = dm_vqf_init(&filter, NULL, 0.0005f);
    return filter_ready;
}

bool fusion_on_sample(const float gyro_rad_s[3], const float acc_mps2[3],
                      float quaternion_wxyz[4])
{
    if (!filter_ready || !quaternion_wxyz) return false;
    if (!dm_vqf_update(&filter, gyro_rad_s, acc_mps2)) return false;
    dm_vqf_get_quaternion(&filter, quaternion_wxyz);
    return true;
}
```

gyro 输入不能仍为 deg/s；若驱动给出 deg/s，在库外乘 `π/180`。加速度若为 g，在库外按实际标定换成 m/s²。两者必须处在同一右手安装坐标系；标准水平静止输入为 `[0,0,+g]`。从原始传感器到库输入之间的标定与坐标变换需与原系统对齐。

四元数输出 `[w,x,y,z]`，表示 body 到六轴参考系的旋转。yaw 没有绝对北向约束。`dm_vqf_get_euler_deg()` 输出 `[roll,pitch,yaw]`，单位 deg，接近万向锁时遵循固件的专门分支；欧拉角不适合作为连续积分状态。

## 5. 两种初始化和两种更新入口

| 入口 | 何时使用 | 行为 |
|---|---|---|
| `dm_vqf_init()` | 默认或明确自定义配置 | 设计系数，清 bias，P=P0*I，周期由参数给定 |
| `dm_vqf_init_from_saved_calibration()` | 对齐厂商保存标定的启动路径 | 固定 0.5 ms，限制保存阈值，载入 bias 和原固件特殊倍率的 P |
| `dm_vqf_update()` | 一般项目的每次采样 | 输入检查通过后只调用一次 core；非法输入不改状态 |
| `dm_vqf_update_core()` | 已统一检查输入或原指令审计 | 不校验指针/有限性，不与 update 连续调用 |

示例：保存标定已经从持久化数据解析出来时：

```c
DmVqfSavedCalibration saved = {
    .valid = true,
    .gyro_bias_dps = { 0.10f, -0.20f, 0.30f },  /* 仅演示，换成真实标定值。 */
    .rest_gyro_threshold_dps = 3.0f,
    .saved_sigma = 0.05f
};
bool ok = dm_vqf_init_from_saved_calibration(&filter, &saved);
```

`saved_sigma` 是原始保存字段。固件先计算 `P0=(sigma*100)²`，再载入 `P=(sigma*5729.578125)²*I`。这是已审计的固件行为，不能为了单位看起来一致改成相同倍率。`dm_vqf_set_bias()` 是通用接口，其 sigma 单位明确为 deg/s，P 倍率为 100，不能替代厂商启动路径。

运行中调用 `dm_vqf_reset()` 清姿态、bias 和所有滤波历史，保留配置和系数；它不会自动重载标定。参数要调整应在暂停更新后重新初始化，不要仅改 `filter.params` 而不重算系数。

## 6. 函数层次与内部阅读路线

主路径按照执行顺序展开，不把多个正常阶段包在一层层条件分支中：

```text
应用的采样处理
  dm_vqf_update()                  输入检查，仅一次
    dm_vqf_update_core()           固定周期的顺序流程
      check_gyro_rest()           必要时更新陀螺稳定参考、否定静止
      integrate_gyro()            减 bias，积分 qG
      [全零 acc -> 提前结束]
      check_acc_rest()            必要时更新稳定计时
      correct_inclination()       近惯性系低通，校正 qA
      [偏置功能全关 -> 提前结束]
      update_bias()               预测、增益、bias/P 更新、限幅
        prepare_bias_measurement() 维护观测低通，选择静止或运动观测

输出读取
  dm_vqf_get_quaternion()          qA⊗qG
  dm_vqf_get_euler_deg()           合成四元数 -> 唯一的转换函数
```

进一步的数学运算集中在 `dm_vqf_math.c`，不会再把核心主流程拆成大量只做一行的小函数。矩阵乘法保留必要的行/列两层循环，低通保留必要的启动状态分支。库没有递归，也没有动态函数回调。

重点函数内部已注明：

- `check_gyro_rest()`：变化量阈值用 `>=`，绝对角速度上限用 `>`；两个等号语义不同。
- `check_acc_rest()`：不稳清零，否则先加 Ts 再检查静止时长；不增加额外的 gyro 成功条件。
- `correct_inclination()`：输出校正前重力方向供偏置残差使用，不能提前改成 `[0,0,1]`。
- `prepare_bias_measurement()`：即使当前静止，也维护运动观测低通，再优先选择静止分支。
- `update_bias()`：无观测时仍预测 P；`Pii<P0` 才加 V，不替换为饱和加法；工作矩阵每一步代表的数学量写在注释中。
- `dm_vqf_math_lowpass_vector()`：启动平均、状态空间复用、转入递推的时机，以及为何要 double 状态。
- `dm_vqf_math_mat3_inverse()`：伴随矩阵元素采用具名局部变量，保留 float 余子式和 double 行列式的舍入位置。

所有公开接口含中文参数、单位、返回值、前置条件和副作用说明，内部函数也有职责与分支解释，可用编辑器悬停查看 Doxygen 注释。

## 7. 编译与调度约束

- 禁止启用 `-ffast-math`、`-ffinite-math-only` 等假定不存在 NaN 的优化：启动低通使用 NaN 状态标记。CMake 不修改上层全局优化选项，项目需要自行检查工具链配置。
- 保留显式 `fmaf()`、表达式分组和 float/double 类型。不保证任意编译器逐位相同，原 BIN 对照给出的是已测范围内的误差。
- 库无锁；一个实例只由一个任务更新。中断与任务同时读写同一实例时，在应用层互斥或先复制输出快照。
- `sizeof(DmVqf)` 由目标 ABI 决定，请在目标上检查状态内存和栈预算；多个实例分别分配即可，库无共享可变全局状态。
- 全零 acc 表示跳过本次加速度相关更新，但 gyro 已积分；NaN/Inf 在安全入口被拒绝。本库没有推断丢样次数、插值或自动重放采样。
- 需要保留原固件补步行为时，应由项目按已审计的时间调度实现；不应随意重复最后一帧并声称恢复了真实丢失数据。

## 8. 行为保持的验证

这次整理保留已有公开 API、状态字段与所有系数；修改集中在注释、内部符号前缀、局部变量命名和主流程的等价提前返回。没有更换低通、矩阵求逆、静止策略或浮点表达式顺序。

开发工作区可执行：

```powershell
& ./bin_analysis/readable_c/build_and_test.ps1
& ./bin_analysis/run_bin_audit.ps1
```

前者与公开 VQF 比较 992000 点；后者执行原 BIN 核心、初始化与边界探针。源代码交付包不包含固件、反汇编、仿真环境或公开参考源码；使用库只需本说明第一节的文件。
