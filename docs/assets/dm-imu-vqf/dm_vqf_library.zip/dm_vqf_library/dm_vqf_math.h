/* SPDX-License-Identifier: MIT
 * 内部数学模块，仅供 dm_vqf.c 和 dm_vqf_math.c 使用。
 * 不属于应用层稳定 API；所有数组和标量约束由调用方保证，避免每层重复检查。
 * 矩阵均为行优先，四元数均为 w,x,y,z；详细算法及边界见对应 .c 函数注释。
 */
#ifndef DM_VQF_MATH_H
#define DM_VQF_MATH_H
#include "dm_vqf.h"
#include <stddef.h>

#define DM_VQF_PI 3.14159265358979323846264338327950288
#define DM_VQF_DEG_TO_RAD ((float)(DM_VQF_PI / 180.0))

/* 基础向量：范数、原地归一化、逐分量对称限幅。 */
float dm_vqf_math_vec_norm(const float *v, size_t count);
void dm_vqf_math_vec_normalize(float *v, size_t count);
void dm_vqf_math_vec_clip(float *v, size_t count, float limit);
/* 四元数乘法/旋转均支持输出与输入原地复用；矩阵展开不可与 q 重叠。 */
void dm_vqf_math_quat_multiply(const float a[4], const float b[4], float out[4]);
void dm_vqf_math_quat_rotate(const float q[4], const float v[3], float out[3]);
void dm_vqf_math_quat_to_matrix(const float q[4], float out[9]);

/* 二阶低通：初始化设计系数，reset 标记启动，vector 每个采样递推一次。 */
void dm_vqf_math_lowpass_design(float tau_s, float dt_s, DmVqfLowpassCoeffs *coeffs);
void dm_vqf_math_lowpass_reset(double *state, size_t dimensions);
/* x 和 out 允许重叠；state 至少 2*dimensions 个 double，dimensions>=2。 */
void dm_vqf_math_lowpass_vector(const float *x, size_t dimensions, float tau_s, float dt_s,
                    const DmVqfLowpassCoeffs *coeffs, double *state, float *out);

/* 三阶矩阵：乘法/求逆均允许输出复用输入；不在此处检查异常数据。 */
void dm_vqf_math_mat3_identity(float scale, float out[9]);
void dm_vqf_math_mat3_multiply(const float a[9], const float b[9], float out[9]);
void dm_vqf_math_mat3_multiply_transpose_left(const float a[9], const float b[9], float out[9]);
void dm_vqf_math_mat3_multiply_transpose_right(const float a[9], const float b[9], float out[9]);
bool dm_vqf_math_mat3_inverse(const float in[9], float out[9]);
#endif
