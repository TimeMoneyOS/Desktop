/* SPDX-FileCopyrightText: 2021 Daniel Laidig <laidig@control.tu-berlin.de>
 * SPDX-License-Identifier: MIT
 * Readable C adaptation of the public VQF six-axis path.
 * 中文注释标明每一步的物理含义；固件地址映射见 README.md。
 */
#include "dm_vqf.h"
#include "dm_vqf_math.h"
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <string.h>

/** @brief 以 float 计算平方，保留乘法的舍入位置，不替换为 pow 或 double。 */
static float square(float x) { return x*x; }

/**
 * @brief 检查一个三维输入是否存在且各分量有限。
 * @return 仅当指针有效且不含 NaN/Inf 时为 true。
 * @note 只由安全接口调用；核心算法入口不会重复进行这层检查。
 */
static bool finite_vector3(const float v[3])
{
    return v && isfinite(v[0]) && isfinite(v[1]) && isfinite(v[2]);
}

/** @brief 构造固件回退参数；数值与位宽保持审计版本，具体单位见公开头文件。 */
DmVqfParams dm_vqf_default_params(void)
{
    DmVqfParams params = {
        .acc_filter_tau_s = 3.0f,
        .estimate_bias_during_motion = true,
        .estimate_bias_at_rest = true,
        .mag_dist_rejection_enabled = true,
        .initial_bias_sigma_dps = 0.5f,
        .bias_forgetting_time_s = 100.0f,
        .bias_clip_dps = 2.0f,
        .motion_bias_sigma_dps = 0.1f,
        .vertical_bias_forgetting_factor = 0.0001f,
        .rest_bias_sigma_dps = 0.03f,
        .rest_min_time_s = 1.5f,
        .rest_filter_tau_s = 0.5f,
        .rest_gyro_threshold_dps = 3.0f,
        .rest_acc_threshold_mps2 = 0.5f
    };
    return params;
}

/**
 * @brief 初始化前检查参数的基本取值范围。
 * @param p 非 NULL 的待检查配置；dt 为固定采样周期。
 * @return 参数满足当前库接口约束为 true，不修改配置。
 * @details 时间常数/噪声等要求有限正数，静止时间和竖直比例允许为零。
 * 这里不宣称接受原 BIN 可出现的任意损坏配置；派生结果还会另查溢出。
 */
static bool valid_params(const DmVqfParams *p, float dt)
{
    const float positive_values[] = {
        dt, p->acc_filter_tau_s, p->initial_bias_sigma_dps,
        p->bias_forgetting_time_s, p->bias_clip_dps, p->motion_bias_sigma_dps,
        p->rest_bias_sigma_dps, p->rest_filter_tau_s,
        p->rest_gyro_threshold_dps, p->rest_acc_threshold_mps2
    };
    for (size_t i = 0; i < sizeof positive_values/sizeof positive_values[0]; ++i) {
        if (!isfinite(positive_values[i]) || positive_values[i] <= 0) return false;
    }
    return isfinite(p->rest_min_time_s) && p->rest_min_time_s >= 0
        && isfinite(p->vertical_bias_forgetting_factor) && p->vertical_bias_forgetting_factor >= 0;
}

/** @brief 初始化的实现：先在局部实例中完成计算，全部成功后一次性提交。 */
bool dm_vqf_init(DmVqf *filter, const DmVqfParams *params, float sample_period_s)
{
    /* 1. 尽早拒绝非法配置，避免错误输入触碰现有实例。 */
    if (!filter) return false;
    DmVqfParams chosen = params ? *params : dm_vqf_default_params();
    if (!valid_params(&chosen, sample_period_s)) return false;

    /* 2. 设计两个低通：主加速度滤波和静止检测滤波共用同一个采样周期。 */
    DmVqf initialized = {0};
    initialized.params = chosen;
    initialized.sample_period_s = sample_period_s;
    dm_vqf_math_lowpass_design(chosen.acc_filter_tau_s, sample_period_s, &initialized.acc_filter);
    dm_vqf_math_lowpass_design(chosen.rest_filter_tau_s, sample_period_s, &initialized.rest_filter);

    /* 3. P 和测量权重采用 VQF 内部的 (0.01 deg/s)^2 单位。
     * 先平方得到配置方差，再构造观测权重；保留表达式和计算顺序。
     * 竖直权重分母下限 1e-10 用于防止零除，不能为了“简化”删去。
     */
    initialized.initial_bias_variance = square(chosen.initial_bias_sigma_dps*100.0f);
    initialized.bias_process_variance = square(10.0f)*sample_period_s/chosen.bias_forgetting_time_s;
    float motion_variance = square(chosen.motion_bias_sigma_dps*100.0f);
    initialized.motion_measurement_variance = square(motion_variance)/initialized.bias_process_variance + motion_variance;
    initialized.vertical_measurement_variance = initialized.motion_measurement_variance
        / fmaxf(chosen.vertical_bias_forgetting_factor, 1e-10f);
    float rest_variance = square(chosen.rest_bias_sigma_dps*100.0f);
    initialized.rest_measurement_variance = square(rest_variance)/initialized.bias_process_variance + rest_variance;

    /* 防止极端参数使权重溢出。正常范围的 DM 参数不会走此分支。 */
    if (!isfinite(initialized.initial_bias_variance)
        || initialized.bias_process_variance <= 0 || !isfinite(initialized.bias_process_variance)
        || !isfinite(initialized.motion_measurement_variance)
        || !isfinite(initialized.vertical_measurement_variance)
        || !isfinite(initialized.rest_measurement_variance)) return false;
    /* 4. 系数已经有效，再构造初始状态并提交；reset 不会改变这些系数。 */
    dm_vqf_reset(&initialized);
    *filter = initialized;
    return true;
}

/**
 * @brief 按厂商保存标定的启动顺序初始化；此函数不包含存储驱动。
 * @details 先生成默认系数/P0，再载入 bias 和特殊倍率 P；不能交换这两步。
 * 完整参数和返回约定见 dm_vqf.h。
 */
bool dm_vqf_init_from_saved_calibration(DmVqf *filter, const DmVqfSavedCalibration *saved)
{
    if (!saved || !saved->valid) return dm_vqf_init(filter, NULL, 0.0005f);
    if (!filter || !finite_vector3(saved->gyro_bias_dps)
        || !isfinite(saved->rest_gyro_threshold_dps) || !isfinite(saved->saved_sigma)) return false;

    /* 已保存值只影响阈值与初始 sigma；其余系数仍取审计过的默认配置。 */
    DmVqfParams params = dm_vqf_default_params();
    float threshold = saved->rest_gyro_threshold_dps;
    if (threshold < 0.5f) threshold = 0.5f;
    else if (threshold > 20.0f) threshold = 20.0f;
    float sigma = saved->saved_sigma;
    if (sigma < 0.05f) sigma = 0.05f;
    params.rest_gyro_threshold_dps = threshold;
    params.initial_bias_sigma_dps = sigma;

    /* 不在已有 filter 上分步修改，以保证任何失败都不留下半初始化状态。 */
    DmVqf initialized;
    if (!dm_vqf_init(&initialized, &params, 0.0005f)) return false;
    for (int i = 0; i < 3; ++i) initialized.bias_rad_s[i] = saved->gyro_bias_dps[i]*DM_VQF_DEG_TO_RAD;
    /* 0x11F9A 读取 0x45B30CA0；P 的倍率与之前计算 P0 的 100 不同。 */
    float scaled_sigma = sigma*5729.578125f;
    float variance = scaled_sigma*scaled_sigma;
    if (!isfinite(variance)) return false;
    dm_vqf_math_mat3_identity(variance, initialized.bias_covariance);
    *filter = initialized;
    return true;
}

/** @brief 清除动态状态但保留配置；低通 NaN 初态代表“重新开始累计平均”。 */
void dm_vqf_reset(DmVqf *filter)
{
    /* 姿态回到参考原点；偏置归零，协方差取 P0。 */
    memset(filter->gyro_quat, 0, sizeof filter->gyro_quat);
    memset(filter->tilt_quat, 0, sizeof filter->tilt_quat);
    filter->gyro_quat[0] = filter->tilt_quat[0] = 1.0f;
    memset(filter->bias_rad_s, 0, sizeof filter->bias_rad_s);
    dm_vqf_math_mat3_identity(filter->initial_bias_variance, filter->bias_covariance);
    /* 清除静止判定与最近一次诊断值，避免复用上次运行结果。 */
    filter->rest_detected = false;
    filter->rest_time_s = 0;
    filter->rest_gyro_deviation_sq = filter->rest_acc_deviation_sq = 0;
    filter->last_tilt_correction_rate_rad_s = 0;
    memset(filter->rest_gyro_lp, 0, sizeof filter->rest_gyro_lp);
    memset(filter->rest_acc_lp, 0, sizeof filter->rest_acc_lp);
    memset(filter->acc_inertial_lp, 0, sizeof filter->acc_inertial_lp);
    /* 每维有两个 double 延迟状态；NaN 是算法状态标记，不能改成全零。 */
    dm_vqf_math_lowpass_reset(filter->acc_filter_state, 3);
    dm_vqf_math_lowpass_reset(filter->rest_gyro_filter_state, 3);
    dm_vqf_math_lowpass_reset(filter->rest_acc_filter_state, 3);
    dm_vqf_math_lowpass_reset(filter->rotation_matrix_filter_state, 9);
    dm_vqf_math_lowpass_reset(filter->rotated_bias_filter_state, 2);
}

/**
 * @brief 第一步：更新陀螺静止检测参考值，发现运动则清除静止状态。
 * @param filter 解算实例；gyro 为机体系 rad/s 原始融合输入，尚未减去 bias。
 * @details 比较 gyro-LPgyro 的模平方；同时检查 LPgyro 各轴绝对值。
 * 变化量恰好等于阈值会清零，但绝对角速度恰好等于 biasClip 不会清零。
 * @note 本函数只负责否定静止；确认静止和增加计时在 check_acc_rest() 完成。
 */
static void check_gyro_rest(DmVqf *filter, const float gyro[3])
{
    const DmVqfParams *p = &filter->params;
    dm_vqf_math_lowpass_vector(gyro, 3, p->rest_filter_tau_s, filter->sample_period_s,
                    &filter->rest_filter, filter->rest_gyro_filter_state, filter->rest_gyro_lp);
    filter->rest_gyro_deviation_sq = square(gyro[0] - filter->rest_gyro_lp[0])
        + square(gyro[1] - filter->rest_gyro_lp[1]) + square(gyro[2] - filter->rest_gyro_lp[2]);

    /* 配置是 deg/s，输入是 rad/s；先换算再比较平方，保持量纲一致。 */
    float limit = p->bias_clip_dps*DM_VQF_DEG_TO_RAD;
    if (filter->rest_gyro_deviation_sq >= square(p->rest_gyro_threshold_dps*DM_VQF_DEG_TO_RAD)
        || fabsf(filter->rest_gyro_lp[0]) > limit
        || fabsf(filter->rest_gyro_lp[1]) > limit
        || fabsf(filter->rest_gyro_lp[2]) > limit) {
        filter->rest_time_s = 0;
        filter->rest_detected = false;
    }
}

/**
 * @brief 第二步：用减去估计零偏的角速度积分陀螺四元数 qG。
 * @param filter 解算实例；gyro 单位 rad/s，使用初始化时的固定 Ts。
 * @details 增量为 [cos(angle/2), sin(angle/2)*omega/|omega|]；qG 右乘增量。
 * |omega|<=FLT_EPSILON 时跳过，避免除以近零角速度；否则乘后归一化。
 * 使用当前 bias，之后的偏置更新只作用于后续采样，不回写本次积分。
 */
static void integrate_gyro(DmVqf *filter, const float gyro[3])
{
    float corrected[3] = {
        gyro[0] - filter->bias_rad_s[0],
        gyro[1] - filter->bias_rad_s[1],
        gyro[2] - filter->bias_rad_s[2]
    };
    float angular_speed = dm_vqf_math_vec_norm(corrected, 3);
    float angle = angular_speed*filter->sample_period_s;
    if (angular_speed > FLT_EPSILON) {
        float sine_factor = sinf(angle/2)/angular_speed;
        float increment[4] = {
            cosf(angle/2), sine_factor*corrected[0],
            sine_factor*corrected[1], sine_factor*corrected[2]
        };
        dm_vqf_math_quat_multiply(filter->gyro_quat, increment, filter->gyro_quat);
        dm_vqf_math_vec_normalize(filter->gyro_quat, 4);
    }
}

/**
 * @brief 第三步：根据机体系加速度变化检测静止并累计静止时间。
 * @param filter 解算实例；acc 单位 m/s²，输入全零时上层不会调用本函数。
 * @details 变化量达到阈值则清零；否则先加 Ts，再检查是否达到 restMinT。
 * @note 同次采样中 gyro 不稳可先清零计时，而 acc 稳定仍会再加一次 Ts。
 * 这个顺序来自原 BIN，不增加额外的“gyro 已失败所以不计时”分支。
 */
static void check_acc_rest(DmVqf *filter, const float acc[3])
{
    const DmVqfParams *p = &filter->params;
    dm_vqf_math_lowpass_vector(acc, 3, p->rest_filter_tau_s, filter->sample_period_s,
                    &filter->rest_filter, filter->rest_acc_filter_state, filter->rest_acc_lp);
    filter->rest_acc_deviation_sq = square(acc[0] - filter->rest_acc_lp[0])
        + square(acc[1] - filter->rest_acc_lp[1]) + square(acc[2] - filter->rest_acc_lp[2]);
    if (filter->rest_acc_deviation_sq >= square(p->rest_acc_threshold_mps2)) {
        filter->rest_time_s = 0;
        filter->rest_detected = false;
    } else {
        filter->rest_time_s += filter->sample_period_s;
        if (filter->rest_time_s >= p->rest_min_time_s) filter->rest_detected = true;
    }
}

/**
 * @brief 第四步：由近惯性系的低通加速度修正倾角四元数 qA。
 * @param[in,out] filter 解算实例，更新 qA、主低通和校正角速度诊断量。
 * @param[in] acc 机体系加速度，m/s²。
 * @param[out] gravity_direction 校正前、六轴参考系中的单位加速度方向。
 * @details 输出方向还用于同次采样的运动零偏残差，不能提前替换成 [0,0,1]。
 * qA 左乘倾角增量；w<=1e-6 时按原算法选择绕 X 轴 180° 分支。
 */
static void correct_inclination(DmVqf *filter, const float acc[3], float gravity_direction[3])
{
    /* 先旋转后滤波：把机体旋转引起的重力投影变化与低通处理分开。 */
    float acc_inertial[3];
    dm_vqf_math_quat_rotate(filter->gyro_quat, acc, acc_inertial);
    dm_vqf_math_lowpass_vector(acc_inertial, 3, filter->params.acc_filter_tau_s, filter->sample_period_s,
                    &filter->acc_filter, filter->acc_filter_state, filter->acc_inertial_lp);
    dm_vqf_math_quat_rotate(filter->tilt_quat, filter->acc_inertial_lp, gravity_direction);
    dm_vqf_math_vec_normalize(gravity_direction, 3);

    /* 已有 qA 把低通结果转到六轴系，据其与 +Z 的偏差构造最短倾角校正。 */
    float correction[4];
    float w = sqrtf((gravity_direction[2] + 1)/2);
    if (w > 1e-6f) {
        correction[0] = w;
        correction[1] = 0.5f*gravity_direction[1]/w;
        correction[2] = -0.5f*gravity_direction[0]/w;
        correction[3] = 0;
    } else {
        /* 重力几乎朝 -Z：180 度分支，避免除以接近零的 w。 */
        correction[0] = 0; correction[1] = 1; correction[2] = 0; correction[3] = 0;
    }
    dm_vqf_math_quat_multiply(correction, filter->tilt_quat, filter->tilt_quat);
    dm_vqf_math_vec_normalize(filter->tilt_quat, 4);

    /* 原 BIN 在 0x1851A 直接调用 acosf；保留越界时的 NaN 诊断行为。 */
    filter->last_tilt_correction_rate_rad_s = acosf(gravity_direction[2])/filter->sample_period_s;
}

/**
 * @brief 第五步 A：构造零偏观测矩阵 H、残差 e 和对角测量权重 W。
 * @param filter 解算实例；gravity 为刚才倾角校正前的单位加速度方向。
 * @param[out] h 行优先 3×3 观测矩阵。
 * @param[out] residual 三轴残差，rad/s，进入 Kalman 更新前另有限幅。
 * @param[out] variance 三个对角测量权重，采用内部协方差缩放单位。
 * @return true 表示观测有效；false 表示应只预测 P、不执行测量更新。
 * @details 始终先维护 R 与 R*b 的低通历史，再选择静止或运动分支。
 * 静止优先：H=I；运动则 H 为低通旋转矩阵，竖直观测采用很大的噪声权重。
 */
static bool prepare_bias_measurement(DmVqf *filter, const float gravity[3],
                                      float h[9], float residual[3], float variance[3])
{
    /* 原 BIN 即使正在静止，也持续更新运动观测低通，避免切换时历史中断。 */
    float attitude[4], rotated_bias[2];
    dm_vqf_get_quaternion(filter, attitude);
    dm_vqf_math_quat_to_matrix(attitude, h);
    rotated_bias[0] = h[0]*filter->bias_rad_s[0] + h[1]*filter->bias_rad_s[1] + h[2]*filter->bias_rad_s[2];
    rotated_bias[1] = h[3]*filter->bias_rad_s[0] + h[4]*filter->bias_rad_s[1] + h[5]*filter->bias_rad_s[2];
    dm_vqf_math_lowpass_vector(h, 9, filter->params.acc_filter_tau_s, filter->sample_period_s,
                    &filter->acc_filter, filter->rotation_matrix_filter_state, h);
    dm_vqf_math_lowpass_vector(rotated_bias, 2, filter->params.acc_filter_tau_s, filter->sample_period_s,
                    &filter->acc_filter, filter->rotated_bias_filter_state, rotated_bias);

    if (filter->rest_detected && filter->params.estimate_bias_at_rest) {
        /* 静止假设真实角速度为零，低通陀螺就是三轴偏置观测。 */
        for (int i = 0; i < 3; ++i) {
            residual[i] = filter->rest_gyro_lp[i] - filter->bias_rad_s[i];
            variance[i] = filter->rest_measurement_variance;
        }
        dm_vqf_math_mat3_identity(1.0f, h);
        return true;
    }
    if (filter->params.estimate_bias_during_motion) {
        /* 倾角校正提供水平偏置信息；保持参考公式的求值顺序。 */
        residual[0] = -gravity[1]/filter->sample_period_s + rotated_bias[0]
            - h[0]*filter->bias_rad_s[0] - h[1]*filter->bias_rad_s[1] - h[2]*filter->bias_rad_s[2];
        residual[1] = gravity[0]/filter->sample_period_s + rotated_bias[1]
            - h[3]*filter->bias_rad_s[0] - h[4]*filter->bias_rad_s[1] - h[5]*filter->bias_rad_s[2];
        residual[2] = -h[6]*filter->bias_rad_s[0] - h[7]*filter->bias_rad_s[1] - h[8]*filter->bias_rad_s[2];
        variance[0] = variance[1] = filter->motion_measurement_variance;
        variance[2] = filter->vertical_measurement_variance;
        return true;
    }
    /* 没有可用观测不是错误；调用方仍需执行协方差随时间增长的预测。 */
    return false;
}

/**
 * @brief 第五步 B：执行三状态偏置 Kalman 更新，保持原矩阵运算次序。
 * @param filter 解算实例；gravity 为同次采样的倾角校正前单位方向。
 * @details 状态仅为 bx/by/bz，不包含四元数。步骤是准备观测、预测 P、
 * 裁剪残差、计算 K、更新 bias、更新 P、裁剪 bias。无观测时在预测后返回。
 * @note Pii<P0 时才加 V，而不是 min(Pii+V,P0)；即使加后越过 P0 也不补裁剪。
 */
static void update_bias(DmVqf *filter, const float gravity[3])
{
    float observation_matrix[9], residual[3], measurement_variance[3];
    bool have_measurement = prepare_bias_measurement(filter, gravity, observation_matrix, residual, measurement_variance);
    float *covariance = filter->bias_covariance;

    /* 即使没有可用观测，也要增加偏置随时间变化的不确定度。 */
    for (int axis = 0; axis < 3; ++axis) {
        int diagonal = 4*axis;
        if (covariance[diagonal] < filter->initial_bias_variance) covariance[diagonal] += filter->bias_process_variance;
    }
    if (!have_measurement) return;

    float clip = filter->params.bias_clip_dps*DM_VQF_DEG_TO_RAD;
    dm_vqf_math_vec_clip(residual, 3, clip);

    /* K = P H^T (H P H^T + W)^-1。
     * 工作矩阵依次表示 P*H^T、H*P*H^T、加 W 后的逆、H^T*逆，最后为 K。
     * 复用它减少栈占用，各辅助函数内部允许输入输出重叠。
     */
    float kalman_work[9];
    dm_vqf_math_mat3_multiply_transpose_right(covariance, observation_matrix, kalman_work);
    dm_vqf_math_mat3_multiply(observation_matrix, kalman_work, kalman_work);
    kalman_work[0] += measurement_variance[0];
    kalman_work[4] += measurement_variance[1];
    kalman_work[8] += measurement_variance[2];
    dm_vqf_math_mat3_inverse(kalman_work, kalman_work);
    dm_vqf_math_mat3_multiply_transpose_left(observation_matrix, kalman_work, kalman_work);
    dm_vqf_math_mat3_multiply(covariance, kalman_work, kalman_work);

    /* 此时工作矩阵为 K：先更新三轴偏置，之后才复用它计算 K*H*P。 */
    for (int axis = 0; axis < 3; ++axis) {
        filter->bias_rad_s[axis] += kalman_work[3*axis]*residual[0]
            + kalman_work[3*axis+1]*residual[1] + kalman_work[3*axis+2]*residual[2];
    }
    /* P = P - K H P。逆矩阵奇异时 helper 输出零矩阵，等价于零增益。 */
    dm_vqf_math_mat3_multiply(kalman_work, observation_matrix, kalman_work);
    dm_vqf_math_mat3_multiply(kalman_work, covariance, kalman_work);
    for (int i = 0; i < 9; ++i) covariance[i] -= kalman_work[i];
    dm_vqf_math_vec_clip(filter->bias_rad_s, 3, clip);
}

/** @brief 安全包装层：只做一次输入检查，再转交核心；失败不推进时间或状态。 */
bool dm_vqf_update(DmVqf *filter, const float gyro_rad_s[3], const float acc_mps2[3])
{
    if (!filter || !finite_vector3(gyro_rad_s) || !finite_vector3(acc_mps2)) return false;
    dm_vqf_update_core(filter, gyro_rad_s, acc_mps2);
    return true;
}

/**
 * @brief 解算总入口的顺序流程；阅读算法从这里开始。
 * @details 每个阶段仅调用一个职责明确的内部函数；全零加速度直接提前返回。
 * 所有系数已在初始化时计算，此处不会按采样反复设计滤波器。
 */
void dm_vqf_update_core(DmVqf *filter, const float gyro_rad_s[3], const float acc_mps2[3])
{
    /* BIN 0x1833C 检查对象第 9 和第 10 字节：restBias 或 magDist。 */
    if (filter->params.estimate_bias_at_rest || filter->params.mag_dist_rejection_enabled) {
        check_gyro_rest(filter, gyro_rad_s);
    }
    /* 陀螺预测必须先执行，不能因 acc 无效而把本次旋转也丢掉。 */
    integrate_gyro(filter, gyro_rad_s);
    if (acc_mps2[0] == 0 && acc_mps2[1] == 0 && acc_mps2[2] == 0) return;
    if (filter->params.estimate_bias_at_rest) check_acc_rest(filter, acc_mps2);

    float gravity_direction[3];
    correct_inclination(filter, acc_mps2, gravity_direction);
    /* 偏置功能全部关闭时提前结束，避免增加无意义的分支嵌套。 */
    if (!filter->params.estimate_bias_during_motion && !filter->params.estimate_bias_at_rest) return;
    update_bias(filter, gravity_direction);
}

/** @brief 按原 BIN 顺序合成 qA⊗qG；仅输出，不推进或修正内部状态。 */
void dm_vqf_get_quaternion(const DmVqf *filter, float out_wxyz[4])
{
    dm_vqf_math_quat_multiply(filter->tilt_quat, filter->gyro_quat, out_wxyz);
}

/** @brief 欧拉角便利接口；计算四元数快照后调用唯一的转换实现，避免维护两套公式。 */
void dm_vqf_get_euler_deg(const DmVqf *filter, float out[3])
{
    float q[4];
    dm_vqf_get_quaternion(filter, q);
    dm_vqf_quaternion_to_euler_deg(q, out);
}

/**
 * @brief 把有限角度包装到 (-180,180]，边界 -180 必须变为 +180。
 * @note 保留原算法的逐次 ±360；不换成 fmod，以免边界与舍入行为发生变化。
 */
static float wrap_degrees(float angle)
{
    while (angle > 180.0f) angle -= 360.0f;
    while (angle <= -180.0f) angle += 360.0f;
    return angle;
}

/** @brief 固件式 ZYX 转换；完整输入/边界约定见公开头文件。 */
void dm_vqf_quaternion_to_euler_deg(const float q[4], float out[3])
{
    /* 与 0x134D2 的求值顺序对应；融合乘加也影响奇异阈值附近的分支。 */
    float norm_sq = fmaf(q[0], q[0], q[1]*q[1]);
    norm_sq = fmaf(q[2], q[2], norm_sq);
    norm_sq = fmaf(q[3], q[3], norm_sq);
    float norm = sqrtf(norm_sq);
    if (!(norm > 0)) { /* 原 ARM BLE 对 unordered(NaN) 也走零输出分支。 */
        out[0] = out[1] = out[2] = 0;
        return;
    }
    /* 只归一化局部副本，不把归一化结果回写到滤波器中。 */
    float w = q[0]/norm, x = q[1]/norm, y = q[2]/norm, z = q[3]/norm;
    float sin_pitch = 2*fmaf(w, y, -z*x);
    float rad_to_deg = (float)(180.0/DM_VQF_PI);
    /* 接近万向锁时，roll 和 yaw 不再独立：固定 roll=0，按固件分支输出 yaw。 */
    if (sin_pitch > 1.0f || sin_pitch < -1.0f || fabsf(sin_pitch) >= 0.99999f) {
        out[0] = 0;
        out[1] = sin_pitch > 0 ? 90.0f : -90.0f;
        out[2] = wrap_degrees((2*atan2f(z, w))*rad_to_deg);
        return;
    }
    /* 非奇异分支；显式 fmaf 保留已审计的融合乘加语义。 */
    float roll_numerator = 2*fmaf(w, x, y*z);
    float roll_denominator = fmaf(-2.0f, fmaf(x, x, y*y), 1.0f);
    float yaw_numerator = 2*fmaf(w, z, x*y);
    float yaw_denominator = fmaf(-2.0f, fmaf(z, z, y*y), 1.0f);
    out[0] = wrap_degrees(atan2f(roll_numerator, roll_denominator)*rad_to_deg);
    out[1] = asinf(sin_pitch)*rad_to_deg;
    out[2] = wrap_degrees(atan2f(yaw_numerator, yaw_denominator)*rad_to_deg);
}

/** @brief 通用偏置设定，检查完成后才提交 bias/P；不触碰姿态和滤波历史。 */
bool dm_vqf_set_bias(DmVqf *filter, const float bias_rad_s[3], float sigma_dps)
{
    if (!filter || !finite_vector3(bias_rad_s) || !isfinite(sigma_dps) || sigma_dps <= 0) return false;
    float variance = square(sigma_dps*100.0f);
    if (!isfinite(variance)) return false;
    memcpy(filter->bias_rad_s, bias_rad_s, sizeof filter->bias_rad_s);
    dm_vqf_math_mat3_identity(variance, filter->bias_covariance);
    return true;
}
