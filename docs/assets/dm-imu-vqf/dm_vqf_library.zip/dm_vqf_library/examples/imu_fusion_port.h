/* SPDX-License-Identifier: MIT */
#ifndef IMU_FUSION_PORT_H
#define IMU_FUSION_PORT_H

#include "dm_vqf.h"

/** @brief 一个样例应用上下文；由应用持有，适合静态分配。 */
typedef struct {
    DmVqf filter;
    bool initialized;
} ImuFusionPort;

/** @brief 同一次更新后的输出快照；单位写在字段名中。 */
typedef struct {
    float quaternion_wxyz[4];
    float roll_pitch_yaw_deg[3];
    float gyro_bias_rad_s[3];
    bool rest_detected;
} ImuFusionOutput;

/**
 * @brief 应用层接入示例：固定 2 kHz 初始化，保留原固件标定路径。
 * @param port 应用上下文，非 NULL；初始化期间不得被采样任务访问。
 * @param saved 已解析标定；NULL 表示回退默认配置。
 * @return 成功后 initialized=true；失败后禁止处理采样，直到重新初始化成功。
 * @note 这是可选接入样例，不属于核心算法，不读 Flash、不初始化外设。
 */
bool imu_fusion_port_init(ImuFusionPort *port, const DmVqfSavedCalibration *saved);

/**
 * @brief 处理一个由传感器数据就绪事件得到的同步采样，并产生输出快照。
 * @param port 已初始化的应用上下文。
 * @param gyro_rad_s 已换算为 rad/s、完成安装坐标变换的三轴陀螺。
 * @param acc_mps2 已换算为 m/s²、完成标定及相同坐标变换的三轴加速度。
 * @param output 可写输出，不能与上下文或输入数组重叠。
 * @return 成功 true；未初始化、空指针或非有限输入 false，不写 output。
 * @pre 应由单个任务串行调用；并发读取共享快照的同步由项目自行实现。
 */
bool imu_fusion_port_process(ImuFusionPort *port, const float gyro_rad_s[3],
                             const float acc_mps2[3], ImuFusionOutput *output);
#endif
