/* SPDX-License-Identifier: MIT
 * 可选应用适配示例；不添加平滑、死区、额外标定或 yaw 锁定等处理。
 */
#include "imu_fusion_port.h"
#include <string.h>

/** @brief 准备一个独立实例；结果直接反映库初始化是否成功。 */
bool imu_fusion_port_init(ImuFusionPort *port, const DmVqfSavedCalibration *saved)
{
    if (!port) return false;
    port->initialized = dm_vqf_init_from_saved_calibration(&port->filter, saved);
    return port->initialized;
}

/** @brief 线性流程：检查上下文、更新一次、读取姿态、复制诊断状态。 */
bool imu_fusion_port_process(ImuFusionPort *port, const float gyro_rad_s[3],
                             const float acc_mps2[3], ImuFusionOutput *output)
{
    /* 未准备就绪则直接返回，不嵌套整段正常路径。 */
    if (!port || !output || !port->initialized) return false;

    /* 采样检查只由安全更新接口做一次；不要再调用 update_core，否则会积分两次。 */
    if (!dm_vqf_update(&port->filter, gyro_rad_s, acc_mps2)) return false;

    /* 全部输出来自本次更新后的同一个实例，复制期间不要让中断更新该实例。 */
    dm_vqf_get_quaternion(&port->filter, output->quaternion_wxyz);
    dm_vqf_get_euler_deg(&port->filter, output->roll_pitch_yaw_deg);
    memcpy(output->gyro_bias_rad_s, port->filter.bias_rad_s, sizeof output->gyro_bias_rad_s);
    output->rest_detected = port->filter.rest_detected;
    return true;
}
