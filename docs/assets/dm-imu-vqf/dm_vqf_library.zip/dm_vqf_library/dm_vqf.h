/* SPDX-License-Identifier: MIT
 * Readable six-axis VQF C port. Algorithm: Daniel Laidig (2021).
 * Reconstructed for study using public VQF sources and DM v2.0.3.0 evidence.
 * This is NOT recovered vendor source or a complete replacement firmware.
 */
#ifndef DM_VQF_H
#define DM_VQF_H

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 解算器的固定配置；初始化时复制进实例，不引用调用方内存。
 * @details 时间单位为秒，角速度阈值/标准差为 deg/s，加速度阈值为 m/s²。
 * 初始化会据此计算低通系数和 Kalman 权重，运行中不要直接修改这些字段。
 */
typedef struct {
    float acc_filter_tau_s;                  /**< 近惯性系加速度低通时间常数，默认 3 s。 */
    bool estimate_bias_during_motion;         /**< 是否利用倾角校正估计运动期间的零偏。 */
    bool estimate_bias_at_rest;               /**< 是否检测静止并估计三轴零偏。 */
    bool mag_dist_rejection_enabled; /* 固件保留标志：六轴路径中也使陀螺静止监测继续运行；本模块无磁更新 */
    float initial_bias_sigma_dps;             /**< 初始化零偏不确定度，默认 0.5 deg/s。 */
    float bias_forgetting_time_s;             /**< 不确定度随时间增长的尺度，默认 100 s。 */
    float bias_clip_dps;                      /**< 偏置/残差限幅和静止角速度上限，默认 2 deg/s。 */
    float motion_bias_sigma_dps;              /**< 运动偏置观测的调节参数，默认 0.1 deg/s。 */
    float vertical_bias_forgetting_factor;    /**< 运动时竖直偏置弱约束比例，默认 0.0001。 */
    float rest_bias_sigma_dps;                /**< 静止偏置观测的调节参数，默认 0.03 deg/s。 */
    float rest_min_time_s;                    /**< 加速度稳定计时达到此值后判静止，默认 1.5 s。 */
    float rest_filter_tau_s;                  /**< 陀螺/加速度静止监测低通时间常数，默认 0.5 s。 */
    float rest_gyro_threshold_dps;            /**< 原始与低通陀螺差的模阈值，默认 3 deg/s。 */
    float rest_acc_threshold_mps2;            /**< 原始与低通加速度差的模阈值，默认 0.5 m/s²。 */
} DmVqfParams;

typedef struct {
    double b[3];                 /* 分子 b0,b1,b2 */
    double a[2];                 /* 分母 a1,a2，a0=1 */
} DmVqfLowpassCoeffs;

/**
 * @brief 一个完整解算实例；可静态分配，多个实例之间没有共享可变状态。
 * @details 姿态、偏置和协方差用 float，低通系数及延迟状态用 double。
 * 结构公开是为了无动态内存地分配实例；运行中应当把它视为只读诊断数据。
 * 同一实例的 update/reset/set_bias 与读取操作需要由调用方串行化。
 * 不直接保存到 Flash：本结构不是稳定的持久化格式，也不兼容固件 RAM 布局。
 */
typedef struct {
    DmVqfParams params;
    float sample_period_s;

    float gyro_quat[4];          /* qG: body -> 近惯性系；w,x,y,z */
    float tilt_quat[4];          /* qA: 近惯性系 -> 六轴参考系 */
    float bias_rad_s[3];         /* 估计的传感器系三轴零偏 */
    float bias_covariance[9];    /* 行优先；内部单位 (0.01 deg/s)^2 */

    bool rest_detected;
    float rest_time_s;                        /**< 静止计时；gyro 不稳定会先清零，acc 稳定时再加 Ts。 */
    float rest_gyro_deviation_sq;             /**< 陀螺与低通之差的模平方，单位 (rad/s)²。 */
    float rest_acc_deviation_sq;              /**< 加速度与低通之差的模平方，单位 (m/s²)²。 */
    float rest_gyro_lp[3];                    /**< 机体系低通陀螺，静止时作为零偏观测。 */
    float rest_acc_lp[3];                     /**< 机体系低通加速度，仅用于静止监测。 */
    float acc_inertial_lp[3];                 /**< 近惯性系低通加速度，用于倾角校正。 */
    float last_tilt_correction_rate_rad_s;    /**< 最近一次倾角校正角速度，仅供诊断，可能为 NaN。 */

    DmVqfLowpassCoeffs acc_filter;
    DmVqfLowpassCoeffs rest_filter;
    double acc_filter_state[6];
    double rest_gyro_filter_state[6];
    double rest_acc_filter_state[6];
    double rotation_matrix_filter_state[18];
    double rotated_bias_filter_state[4];

    float initial_bias_variance;              /**< P0：P 的预测增长参考上限；标定载入后 P 可大于它。 */
    float bias_process_variance;              /**< V：每次有效 acc 更新给 P 对角线增加的过程噪声。 */
    float motion_measurement_variance;        /**< Wmotion：运动水平观测权重。 */
    float vertical_measurement_variance;      /**< Wvertical：运动竖直弱约束权重。 */
    float rest_measurement_variance;          /**< Wrest：静止三轴观测共用的权重。 */
} DmVqf;

/* 已从厂商存储格式解析出的值，不直接映射 packed Flash 内存。 */
typedef struct {
    bool valid;
    float gyro_bias_dps[3];
    float rest_gyro_threshold_dps;
    float saved_sigma; /* 原始存储值：按 BIN 的两种倍率分别使用，不擅自修正单位 */
} DmVqfSavedCalibration;

/**
 * @brief 获取已审计的固件回退配置。
 * @return 按值返回配置，无须释放；不会初始化或修改任何解算实例。
 * @note 本函数不包含采样周期，也不读取 Flash。对齐固件请用 0.0005f 初始化。
 */
DmVqfParams dm_vqf_default_params(void);

/**
 * @brief 根据配置计算系数并复位一个解算实例。
 * @param[out] filter 由调用方分配的实例，不能为 NULL。
 * @param[in] params 配置；NULL 表示使用固件回退配置。初始化后无需保留此指针。
 * @param[in] sample_period_s 固定采样周期，须为有限正数；原固件为 0.0005f。
 * @return 成功为 true；配置非法或系数溢出为 false，失败时不修改 filter。
 * @details 依次检查参数、设计低通、计算偏置权重、复位状态，最后提交结果。
 * 成功后姿态为单位四元数、零偏为零、P=P0*I；此前滤波历史全部丢弃。
 * @note 这是带参数检查的库接口；改变采样周期或参数会改变解算行为。
 */
bool dm_vqf_init(DmVqf *filter, const DmVqfParams *params, float sample_period_s);
/**
 * @brief 按原固件“初始化后再载入标定”的顺序创建实例，周期固定为 0.5 ms。
 * @param[out] filter 由调用方分配的实例。
 * @param[in] saved 已解析的标定；NULL 或 valid=false 使用未标定回退路径。
 * @return 成功 true；非法值或溢出 false，失败时实例保持不变。
 * @details rest 阈值限制到 [0.5,20]；sigma 下限为 0.05；偏置从 deg/s 转 rad/s。
 * P0=(sigma*100)²，但载入后的 P=(sigma*5729.578125)²*I。
 * 两个倍率来自原 BIN，必须保留；不要用通用 set_bias() 替代此调用。
 * @note 不执行 Flash 读取或现场标定。非有限值拒绝属于库接口保护。
 */
bool dm_vqf_init_from_saved_calibration(DmVqf *filter, const DmVqfSavedCalibration *saved);
/**
 * @brief 复位姿态和滤波历史，保留已有参数、采样周期及派生系数。
 * @param[in,out] filter 必须已经初始化且非 NULL。
 * @details 两个四元数设为单位值，bias 清零，P 设为 P0*I，低通重新进入启动平均。
 * @note 不会自动重载先前的标定零偏；需要重现标定启动过程时重新调用标定初始化。
 */
void dm_vqf_reset(DmVqf *filter);

/**
 * @brief 项目推荐入口：检查输入后处理一个同步陀螺/加速度采样。
 * @param[in,out] filter 已成功初始化的实例。
 * @param[in] gyro_rad_s 三轴角速度，单位 rad/s，右手系，已完成量纲与安装坐标转换。
 * @param[in] acc_mps2 同次三轴加速度，单位 m/s²；标准水平静止输入为 [0,0,+g]。
 * @return true 表示完成本次更新；空指针或 NaN/Inf 为 false，且不改变任何状态。
 * @details 使用初始化时的固定周期，不读取时钟，不自动补步，不做输入标定。
 * 三轴 acc 全零仍返回 true：陀螺已更新，但 acc、静止 acc 计时及偏置测量更新跳过。
 * 内部不会保存输入指针；输入数组不能指向本实例中会被更新的状态字段。
 */
bool dm_vqf_update(DmVqf *filter, const float gyro_rad_s[3], const float acc_mps2[3]);
/**
 * @brief 无输入检查的六轴核心，主要用于指令级对照或已统一检查输入的工程。
 * @param[in,out] filter 已初始化且非 NULL 的独占实例。
 * @param[in] gyro_rad_s 有效的三轴角速度指针，单位 rad/s。
 * @param[in] acc_mps2 有效的三轴加速度指针，单位 m/s²。
 * @details 顺序为 gyro 静止监测、陀螺积分、acc 静止监测、倾角校正、零偏更新。
 * 不做有限性检查；NaN/Inf 可污染状态。一般项目使用 dm_vqf_update()。
 */
void dm_vqf_update_core(DmVqf *filter, const float gyro_rad_s[3], const float acc_mps2[3]);
/**
 * @brief 合成 qA⊗qG，读取 body 到六轴参考系的姿态四元数。
 * @param[in] filter 已初始化实例；读取期间不能被另一线程/中断更新。
 * @param[out] out_wxyz 至少 4 个 float，顺序 w,x,y,z，单位无量纲。
 * @details 本函数不推进滤波，也不额外归一化。六轴参考系无绝对北向约束。
 * @pre 两个指针均有效，输出数组与实例存储区不重叠。
 */
void dm_vqf_get_quaternion(const DmVqf *filter, float out_wxyz[4]);

/**
 * @brief 读取当前姿态的 ZYX 欧拉角，保留已审计的固件奇异点处理。
 * @param[in] filter 已初始化且非 NULL 的实例。
 * @param[out] out_roll_pitch_yaw 至少 3 个 float：roll、pitch、yaw，单位 deg。
 * @details 先合成四元数，再调用 dm_vqf_quaternion_to_euler_deg()；不修改实例。
 * roll/yaw 范围为 (-180,180]，pitch 范围为 [-90,90]，不含通信层包装。
 * @pre 输出不与实例重叠；读取与更新由调用方互斥。
 */
void dm_vqf_get_euler_deg(const DmVqf *filter, float out_roll_pitch_yaw[3]);
/**
 * @brief 将给定四元数转换为固件约定的 ZYX 欧拉角，不依赖解算实例。
 * @param[in] q_wxyz 输入 w,x,y,z；内部使用局部归一化值，不修改输入。
 * @param[out] out_roll_pitch_yaw 输出 roll、pitch、yaw，单位 deg；不可与输入重叠。
 * @details 范数为零或 NaN 输出全零；常规分支使用 atan2/asin。
 * |sin(pitch)|>=0.99999 时 roll=0、pitch=±90、yaw=2*atan2(z,w)。
 * -180° 包装为 +180°。此处阈值及求值顺序来自原 BIN，不随意改写。
 * @pre 指针有效；正常使用应传入有限四元数，Inf 不属于受支持输入。
 */
void dm_vqf_quaternion_to_euler_deg(const float q_wxyz[4], float out_roll_pitch_yaw[3]);

/**
 * @brief 通用零偏设定接口：设置 bias，并用标准 deg/s 不确定度重设 P。
 * @param[in,out] filter 已初始化的实例。
 * @param[in] bias_rad_s 三轴零偏，单位 rad/s，须为有限值。
 * @param[in] sigma_dps 标准差，单位 deg/s，须为有限正数。
 * @return 成功 true；空指针、非法值或方差溢出 false，不改变实例。
 * @details 设置 P=(sigma_dps*100)²*I；不复位姿态、静止计时和低通历史，
 * 不修改 P0，也不立即把 bias 裁剪到 biasClip；后续正常滤波按原有逻辑处理。
 * @note 不是厂商标定载入接口；复刻原固件启动应调用 init_from_saved_calibration()。
 */
bool dm_vqf_set_bias(DmVqf *filter, const float bias_rad_s[3], float sigma_dps);

#ifdef __cplusplus
}
#endif
#endif
