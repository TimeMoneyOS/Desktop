/* SPDX-FileCopyrightText: 2021 Daniel Laidig <laidig@control.tu-berlin.de>
 * SPDX-License-Identifier: MIT
 * C adaptation of VQF numerical helpers; see LICENSE and README.md.
 */
#include "dm_vqf_math.h"
#include <float.h>
#include <math.h>
#include <string.h>

/**
 * @brief 求向量的欧氏范数 sqrt(sum(v[i]²))，保持 float 累加。
 * @param v 有效输入数组；count 为分量个数，数组至少有 count 个元素。
 * @return 非负范数；不拦截 NaN/Inf，异常值按数学库规则传播。
 */
float dm_vqf_math_vec_norm(const float *v, size_t count)
{
    float squared_norm = 0.0f;
    for (size_t i = 0; i < count; ++i) squared_norm += v[i] * v[i];
    return sqrtf(squared_norm);
}

/**
 * @brief 原地归一化向量/四元数，过小的范数保持原值。
 * @param[in,out] v 有效数组；count 为分量数。
 * @details norm<FLT_EPSILON 时跳过，等于门限仍执行除法；不新增钳位或单位值替代。
 */
void dm_vqf_math_vec_normalize(float *v, size_t count)
{
    float length = dm_vqf_math_vec_norm(v, count);
    if (length < FLT_EPSILON) return;
    for (size_t i = 0; i < count; ++i) v[i] /= length;
}

/**
 * @brief 原地把各分量限制在 [-limit,+limit]，用于偏置及观测残差。
 * @param v 有效可写数组；count 为元素数；limit 为非负幅度。
 * @note 等于边界不改写；NaN 的普通比较均为 false，不在这里转为零。
 */
void dm_vqf_math_vec_clip(float *v, size_t count, float limit)
{
    for (size_t i = 0; i < count; ++i) {
        if (v[i] < -limit) v[i] = -limit;
        else if (v[i] > limit) v[i] = limit;
    }
}

/**
 * @brief Hamilton 四元数乘法 out=a⊗b，分量顺序均为 w,x,y,z。
 * @param a 左因子；b 右因子；out 输出，均为至少 4 个 float。
 * @details 允许 out 与任意输入相同；先计算全部临时量再写回。
 * 不归一化，也不交换乘法顺序；旋转复合一般不满足交换律。
 */
void dm_vqf_math_quat_multiply(const float a[4], const float b[4], float out[4])
{
    /* 临时变量保证 out 可以与任意输入为同一个数组。 */
    float w = a[0]*b[0] - a[1]*b[1] - a[2]*b[2] - a[3]*b[3];
    float x = a[0]*b[1] + a[1]*b[0] + a[2]*b[3] - a[3]*b[2];
    float y = a[0]*b[2] - a[1]*b[3] + a[2]*b[0] + a[3]*b[1];
    float z = a[0]*b[3] + a[1]*b[2] - a[2]*b[1] + a[3]*b[0];
    out[0] = w; out[1] = x; out[2] = y; out[3] = z;
}

/**
 * @brief 用单位四元数 q 主动旋转三维向量，out=R(q)*v。
 * @param q 单位四元数 w,x,y,z；v 输入向量；out 输出，可与 v 为同一数组。
 * @details 不在此处归一化 q；上层维持四元数单位长度。先求全部分量再写出。
 * qG 用于 body->近惯性系，qA 用于近惯性系->六轴参考系。
 */
void dm_vqf_math_quat_rotate(const float q[4], const float v[3], float out[3])
{
    float x = (1 - 2*q[2]*q[2] - 2*q[3]*q[3])*v[0]
            + 2*v[1]*(q[2]*q[1] - q[0]*q[3]) + 2*v[2]*(q[0]*q[2] + q[3]*q[1]);
    float y = 2*v[0]*(q[0]*q[3] + q[2]*q[1])
            + v[1]*(1 - 2*q[1]*q[1] - 2*q[3]*q[3]) + 2*v[2]*(q[2]*q[3] - q[1]*q[0]);
    float z = 2*v[0]*(q[3]*q[1] - q[0]*q[2]) + 2*v[1]*(q[0]*q[1] + q[3]*q[2])
            + v[2]*(1 - 2*q[1]*q[1] - 2*q[2]*q[2]);
    out[0] = x; out[1] = y; out[2] = z;
}

/**
 * @brief 将单位四元数展开为行优先 3×3 旋转矩阵。
 * @param q 输入 w,x,y,z；out 至少 9 个 float，与 q 不重叠。
 * @details 第 r 行第 c 列为 out[3*r+c]；用于把机体系偏置映射到参考系观测。
 */
void dm_vqf_math_quat_to_matrix(const float q[4], float out[9])
{
    out[0] = 1 - 2*q[2]*q[2] - 2*q[3]*q[3];
    out[1] = 2*(q[2]*q[1] - q[0]*q[3]);
    out[2] = 2*(q[0]*q[2] + q[3]*q[1]);
    out[3] = 2*(q[0]*q[3] + q[2]*q[1]);
    out[4] = 1 - 2*q[1]*q[1] - 2*q[3]*q[3];
    out[5] = 2*(q[2]*q[3] - q[1]*q[0]);
    out[6] = 2*(q[3]*q[1] - q[0]*q[2]);
    out[7] = 2*(q[0]*q[1] + q[3]*q[2]);
    out[8] = 1 - 2*q[1]*q[1] - 2*q[2]*q[2];
}

/**
 * @brief 由时间常数设计二阶 Butterworth 低通，只在初始化阶段调用。
 * @param tau_s 有限正时间常数；dt_s 有限正采样周期，均以秒为单位。
 * @param[out] coeffs 输出 double 分子 b0,b1,b2 及分母 a1,a2（a0=1）。
 * @details fc=sqrt(2)/(2*pi*tau)，使用 tan 预畸变。tau<Ts/2 才采用直通，
 * 等于门限仍计算正常系数。输入合法性由上层初始化接口负责检查。
 */
void dm_vqf_math_lowpass_design(float tau_s, float dt_s, DmVqfLowpassCoeffs *coeffs)
{
    /* 太小的时间常数采用直通，避免接近 Nyquist 时的不稳定。 */
    if (tau_s < dt_s / 2) {
        coeffs->b[0] = 1; coeffs->b[1] = 0; coeffs->b[2] = 0;
        coeffs->a[0] = 0; coeffs->a[1] = 0;
        return;
    }
    const double sqrt_two = 1.41421356237309504880168872420969808;
    double cutoff_hz = (sqrt_two / (2.0 * DM_VQF_PI)) / (double)tau_s;
    double c = tan(DM_VQF_PI * cutoff_hz * (double)dt_s);
    double denominator = c*c + sqrt(2.0)*c + 1;
    double b0 = c*c / denominator;
    coeffs->b[0] = b0;
    coeffs->b[1] = 2*b0;
    coeffs->b[2] = b0;
    coeffs->a[0] = 2*(c*c - 1) / denominator;
    coeffs->a[1] = (1 - sqrt(2.0)*c + c*c) / denominator;
}

/**
 * @brief 把低通状态设置为 NaN，触发后续输入累计平均。
 * @param state 可写状态，至少 2*dimensions 个 double；dimensions 为向量维度。
 * @note 不是把输出变成 NaN；下次 dm_vqf_math_lowpass_vector() 会识别并处理这个初始化标记。
 */
void dm_vqf_math_lowpass_reset(double *state, size_t dimensions)
{
    for (size_t i = 0; i < 2*dimensions; ++i) state[i] = NAN;
}

/**
 * @brief 对一个多维向量执行共享系数、独立状态的二阶低通。
 * @param x 输入 float 向量；dimensions>=2，算法使用 2/3/9 维。
 * @param tau_s 初始平均持续时间；dt_s 固定周期；coeffs 为已设计好的系数。
 * @param[in,out] state 至少 2*dimensions 个 double，先经 dm_vqf_math_lowpass_reset()。
 * @param[out] out 输出 float 向量，允许与 x 完全相同；不能与 state 重叠。
 * @details 启动阶段输出累计均值；count*Ts>=tau 时把均值转换成稳态初始延迟。
 * 从下一次输入开始按 biquad 递推。此函数不分配内存，不重新设计系数。
 */
void dm_vqf_math_lowpass_vector(const float *x, size_t dimensions, float tau_s, float dt_s,
                    const DmVqfLowpassCoeffs *coeffs, double *state, float *out)
{
    const double *b = coeffs->b;
    const double *a = coeffs->a;

    /* 启动阶段先平均 tau 秒，避免用第一个样本决定全部初态。
     * 此时 state[0]=NaN，state[1]=计数，state[2..]=各维累计和。
     * 平均结束后，同一块空间切换为每维两个 biquad 延迟状态。
     */
    if (isnan(state[0])) {
        if (isnan(state[1])) {
            state[1] = 0;
            for (size_t i = 0; i < dimensions; ++i) state[2+i] = 0;
        }
        state[1]++;
        for (size_t i = 0; i < dimensions; ++i) {
            state[2+i] += (double)x[i];
            out[i] = (float)(state[2+i] / state[1]);
        }
        /* 必须先计算所有维度的均值，再覆盖同一块空间为延迟状态。 */
        if ((float)state[1] * dt_s >= tau_s) {
            for (size_t i = 0; i < dimensions; ++i) {
                state[2*i] = (double)out[i] * (1 - b[0]);
                state[2*i+1] = (double)out[i] * (b[2] - a[1]);
            }
        }
        return;
    }

    /* 二阶 Butterworth，转置直接 II 型；保留 double 累加精度。 */
    for (size_t i = 0; i < dimensions; ++i) {
        double input = (double)x[i];
        double output = b[0]*input + state[2*i];
        state[2*i] = b[1]*input - a[0]*output + state[2*i+1];
        state[2*i+1] = b[2]*input - a[1]*output;
        out[i] = (float)output;
    }
}

/**
 * @brief 构造 scale*I；输出行优先，非对角全部清零。
 * @param scale 对角元素；out 至少 9 个 float。
 * @details 用于初始 P，以及静止观测 H=I，不能只覆盖对角而保留历史非对角值。
 */
void dm_vqf_math_mat3_identity(float scale, float out[9])
{
    memset(out, 0, 9*sizeof(float));
    out[0] = out[4] = out[8] = scale;
}

/**
 * @brief 三阶矩阵乘法的共用实现，转置标志只改变读索引。
 * @param a,b 行优先 3×3 输入；out 输出，可与任一输入重叠。
 * @param transpose_a,transpose_b 是否在读取时转置对应输入，不生成转置副本。
 * @details 两层循环枚举输出位置，三个乘加项保持原审计次序。
 * 临时矩阵计算完整后一次 memcpy，保证原地调用不会覆盖尚未使用的输入。
 */
static void matrix_product(const float a[9], const float b[9], float out[9],
                           bool transpose_a, bool transpose_b)
{
    float temporary[9];
    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            /* a 起点和步长选择行或列；b 同理，不把 3 项改为重新排序的累加。 */
            int a0 = transpose_a ? row : 3*row;
            int a_step = transpose_a ? 3 : 1;
            int b0 = transpose_b ? 3*col : col;
            int b_step = transpose_b ? 1 : 3;
            temporary[3*row+col] = a[a0]*b[b0]
                + a[a0+a_step]*b[b0+b_step]
                + a[a0+2*a_step]*b[b0+2*b_step];
        }
    }
    memcpy(out, temporary, sizeof temporary);
}

/** @brief out=a*b；有效的 9 元素行优先数组，允许 out 与任一输入相同。 */
void dm_vqf_math_mat3_multiply(const float a[9], const float b[9], float out[9])
{ matrix_product(a, b, out, false, false); }

/** @brief out=a^T*b；用于 H^T*S^-1，数组及重叠约定同普通矩阵乘法。 */
void dm_vqf_math_mat3_multiply_transpose_left(const float a[9], const float b[9], float out[9])
{ matrix_product(a, b, out, true, false); }

/** @brief out=a*b^T；用于 P*H^T，数组及重叠约定同普通矩阵乘法。 */
void dm_vqf_math_mat3_multiply_transpose_right(const float a[9], const float b[9], float out[9])
{ matrix_product(a, b, out, false, true); }

/**
 * @brief 用伴随矩阵/行列式求三阶逆矩阵，保留固件奇异判断范围。
 * @param in 行优先 9 元素输入；out 输出，允许与 in 完全相同。
 * @return det 在闭区间 [-FLT_EPSILON,+FLT_EPSILON] 时清零输出并返回 false；
 * 否则返回 true。调用方把零逆矩阵作为零增益，不另加正则化分支。
 * @details 余子式先 float 乘减再转 double，det 与除法用 double；最后转回 float。
 * 不检测 NaN/Inf，不能把它当作通用健壮矩阵求逆器使用。
 */
bool dm_vqf_math_mat3_inverse(const float in[9], float out[9])
{
    /* 保留参考实现的求值精度：先做 float 乘减，再转 double 求 det。 */
    double adjugate_00 = (double)(in[4]*in[8] - in[5]*in[7]);
    double adjugate_01 = (double)(in[2]*in[7] - in[1]*in[8]);
    double adjugate_02 = (double)(in[1]*in[5] - in[2]*in[4]);
    double adjugate_10 = (double)(in[5]*in[6] - in[3]*in[8]);
    double adjugate_11 = (double)(in[0]*in[8] - in[2]*in[6]);
    double adjugate_12 = (double)(in[2]*in[3] - in[0]*in[5]);
    double adjugate_20 = (double)(in[3]*in[7] - in[4]*in[6]);
    double adjugate_21 = (double)(in[1]*in[6] - in[0]*in[7]);
    double adjugate_22 = (double)(in[0]*in[4] - in[1]*in[3]);
    double determinant = (double)in[0]*adjugate_00 + (double)in[1]*adjugate_10 + (double)in[2]*adjugate_20;
    if (determinant >= -FLT_EPSILON && determinant <= FLT_EPSILON) {
        memset(out, 0, 9*sizeof(float));
        return false;
    }
    out[0] = (float)(adjugate_00/determinant); out[1] = (float)(adjugate_01/determinant); out[2] = (float)(adjugate_02/determinant);
    out[3] = (float)(adjugate_10/determinant); out[4] = (float)(adjugate_11/determinant); out[5] = (float)(adjugate_12/determinant);
    out[6] = (float)(adjugate_20/determinant); out[7] = (float)(adjugate_21/determinant); out[8] = (float)(adjugate_22/determinant);
    return true;
}
